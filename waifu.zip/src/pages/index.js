import React from "react"
import Component from "./component"

// import { Provider } from "react-redux"
// import store from "../stores/root.store"

// const HomeContainer = styled.div`
//   ${({ blurred }) => blurred && `filter: brightness(20%); overflow-y: hidden;`};
// `

const Home = () => {
  // const [showModal, setShowModal] = useState(false)
  // const [selectedQuickPosition, setSelectedQuickPosition] = useState("")

  // const setupQuickApply = positionName => {
  //   setSelectedQuickPosition(positionName)
  //   setShowModal(true)
  // }

  return (
    // <Provider store={store}>
    <Component />
    // </Provider>
  )
}

export default Home
