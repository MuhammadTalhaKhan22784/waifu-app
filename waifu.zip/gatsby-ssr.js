// import 'bootstrap/dist/css/bootstrap.min.css'
// import './src/main'
export { default as wrapRootElement } from './src/wrapper/redux'