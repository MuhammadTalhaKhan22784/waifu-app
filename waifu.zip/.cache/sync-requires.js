

// prefer default export if available
const preferDefault = m => (m && m.default) || m


exports.components = {
  "component---cache-dev-404-page-js": (preferDefault(require("G:\\React\\Raja Client\\new waifu\\waifu\\.cache\\dev-404-page.js"))),
  "component---src-pages-component-js": (preferDefault(require("G:\\React\\Raja Client\\new waifu\\waifu\\src\\pages\\component.js"))),
  "component---src-pages-index-js": (preferDefault(require("G:\\React\\Raja Client\\new waifu\\waifu\\src\\pages\\index.js")))
}

