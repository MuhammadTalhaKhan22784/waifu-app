// import 'bootstrap/dist/css/bootstrap.min.css'
export { default as wrapRootElement } from './src/wrapper/redux'
